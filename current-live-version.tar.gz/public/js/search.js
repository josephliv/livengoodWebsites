console.log("hey there, from the search.js file in public >js !")

$(document).ready( function () {
    $('#lead_table').DataTable();
} );