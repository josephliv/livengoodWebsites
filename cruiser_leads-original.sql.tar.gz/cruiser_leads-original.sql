-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 08, 2024 at 11:19 PM
-- Server version: 8.0.36-0ubuntu0.20.04.1
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cruiser_leads`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_priority` bigint NOT NULL,
  `order` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `default_priority`, `order`, `created_at`, `updated_at`) VALUES
(1, 'New', 0, 1, NULL, NULL),
(2, 'Experienced', 0, 2, NULL, NULL),
(4, 'Veteran', 0, 3, NULL, NULL),
(5, 'Admin', 0, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_07_05_234008_create_lead_mails_table', 2),
(5, '2020_07_13_190838_create_priorities_table', 3),
(6, '2020_07_15_225909_create_groups_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('marcelo@cruisertravels.com', '$2y$10$bjGC1k2afODrQ.DvtrI3qutufxaKs3wV.bz1pbf0b/U1xvLK7JQ82', '2021-07-12 18:07:15'),
('testing@example.com', '$2y$10$80OJDPd6i5eKVrYq.2vKbe8LZcYsMhf1AlbVwSU5mSuaqQJg1SCHK', '2024-02-11 00:05:23');

-- --------------------------------------------------------

--
-- Table structure for table `priorities`
--

CREATE TABLE `priorities` (
  `id` bigint UNSIGNED NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` int NOT NULL,
  `condition` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_to_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_group` bigint DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `priorities`
--

INSERT INTO `priorities` (`id`, `description`, `field`, `condition`, `send_to_email`, `user_group`, `priority`, `created_at`, `updated_at`) VALUES
(4, 'Voice Message', 1, 'FVS voice message from', NULL, 2, 2, '2020-07-14 11:39:53', '2023-03-07 12:38:29'),
(5, 'Cruise Compete', 1, 'CruiseCompete+Request+ID:', NULL, 0, 3, '2020-07-14 15:05:54', '2022-06-30 13:19:24'),
(6, 'Azamara Notifications', 2, 'wendissupport@azamaraclubcruises.com', 'invoices@cruisertravels.com', 0, 0, '2020-07-14 16:45:21', '2023-03-07 12:41:02'),
(7, 'Cruise Compete 2', 1, 'cruise compete', NULL, 0, 5, '2020-07-14 19:46:45', '2023-03-07 12:43:46'),
(8, 'FCC Lead of Former Agent', 1, 'FCC lead', NULL, 2, 51, '2020-07-14 19:47:54', '2023-01-30 19:23:39'),
(9, 'CruiserTravels.com Search Home Page', 1, 'QUOTE REQUEST ON CRUISERTRAVELS.COM', NULL, 2, 6, '2020-07-14 19:52:07', '2021-12-28 19:03:20'),
(10, 'Bookings for User', 2, 'edwin_saenz29@gmail.com', NULL, 2, 20, '2020-07-14 19:56:51', '2021-10-05 14:27:56'),
(11, 'Group Cruise Compete Lead', 1, 'New Group Cruise Quote Request', NULL, 4, 4, '2020-07-14 19:58:04', '2023-03-07 12:43:34'),
(12, 'Contact Us', 1, 'cruisertravels.com Contact: Form Submission', NULL, 2, 8, '2020-07-14 19:58:56', '2021-12-27 15:26:54'),
(13, 'Facebook/Instagram', 2, 'admin@leadsync.me', NULL, 2, 6, '2020-07-14 19:59:32', '2023-03-07 12:44:46'),
(15, 'Royal Caribbean for Invoices', 2, 'noreply@rccl.com', 'invoices@cruisertravels.com', 0, 0, '2020-07-17 16:08:04', '2023-03-07 12:41:32'),
(16, 'Celebrity Cruises for Invoices', 2, 'noreply@celebritycruises.com', 'invoices@cruisertravels.com', 0, 0, '2020-07-17 16:10:49', '2023-03-07 12:41:41'),
(17, 'Azamara Notifications to Invoices', 2, 'donotreply@azamaraclubcruises.com', 'invoices@cruisertravels.com', 0, 0, '2020-07-17 16:56:29', '2023-03-07 12:41:50'),
(18, 'Royal DO NOT REPLY', 2, 'donotreply@royalcaribbean.com', 'invoices@cruisertravels.com', NULL, 0, '2020-07-22 14:25:11', '2020-07-22 14:25:11'),
(19, 'Do Not Reply Celebrity', 2, 'donotreply@celebritycruises.com', 'invoices@cruisertravels.com', 0, 0, '2020-07-23 15:44:15', '2023-03-07 12:42:00'),
(20, 'Website Leads', 2, 'noreply@fs8.formsite.com', NULL, 2, 51, '2020-07-27 17:09:53', '2023-01-30 19:24:18'),
(23, 'rlevinstein@cruisecompete.com', 2, 'rlevinstein@cruisecompete.com', 'cs@cruisertravels.com', 0, 0, '2022-02-22 14:57:51', '2024-02-28 16:20:44'),
(24, 'Cabin Hold Requests', 2, 'ccnotify@cruisecompete.com', NULL, 2, 1, '2023-03-02 10:53:32', '2023-03-08 08:15:19'),
(25, 'Screenshot Website Chat Lead', 1, 'screenshot', NULL, NULL, 15, '2023-09-15 14:53:15', '2023-09-15 14:53:15'),
(26, 'New booking', 2, 'cs@cruisertravels.com', NULL, 2, 2, '2024-01-24 09:58:42', '2024-01-24 09:58:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_admin` int DEFAULT '0',
  `leads_allowed` int DEFAULT NULL,
  `time_set_init` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_set_final` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_group` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `is_admin`, `leads_allowed`, `time_set_init`, `time_set_final`, `user_group`, `created_at`, `updated_at`) VALUES
(1, 'Chris Lounder (Admin)', 'chris@cruisertravels.com', '2020-06-26 22:54:28', '$2y$10$Mek00UyqxPFT9kEac7gzlO83OXmW93onorh96ePH3g/2Pf/d8BwNi', 'nAEp5iu80aBfoPRBDvkLogv83uJ68mq74i6ffhr2zVFDFIIn6QVXBHp6WbCs', 1, 100000, '09:00', '23:59', 5, '2020-06-26 22:54:28', '2020-07-06 19:42:10'),
(3, 'Kathy Wilhelm', 'kathy@cruisertravels.com', NULL, '$2y$10$KkJ30.ftlVo4o2hn2Y2OfektOODY5yMJKmJ6Jau52p/VXGeSfm.3S', 'DKvWsEzM586Fjsv8I0yCGcJILETF07IEvMaJqWbStPxsLsx03RT0qjPfrIj1', 0, 25, '00:01', '23:59', 4, '2020-07-06 19:38:12', '2024-02-14 08:36:45'),
(4, 'Laurie Dumond', 'laurie@cruisertravels.com', NULL, '$2y$10$mAUhpcwQwP0F4uWiXgqR5eiIlcJ9D0UHPowrnIV0JUzDDqBobur5a', 'rbV5TSFnrIl2odk1mjGnmy7QdFF8gOEv4WfM1jQ4hTjZ1KrgBL3vu6EA5eOP', 0, 8, '09:00', '23:59', 2, '2020-07-06 19:39:29', '2023-02-14 13:57:41'),
(20, 'Customer Service', 'cs@cruisertravels.com', NULL, '$2y$10$e59MpS6LHPC0ubMEorR.fe2.ZlIKQXtMz0XYNYBoF3529tKlAXp4G', NULL, 0, 50, '06:00', '19:00', 4, '2021-05-03 12:47:34', '2021-08-16 11:54:08'),
(25, 'Lesly Eyzaguirre', 'lesly@cruisertravels.com', NULL, '$2y$10$.rGX4S2LpJmmh4.YTM.aiuaKixM6mnsW3q3.q4fGY5Ytg2S3xfz1a', 'dQFoGyvFCmWxgGNEZsdukXK2rUk1rhhvx2iiKSVDM00ViIlGOej9PdW1dM2R', 1, 25, '09:00', '23:59', 5, '2021-09-30 00:26:21', '2022-10-06 14:33:46'),
(29, 'Nick Lopez', 'nick@cruisertravels.com', NULL, '$2y$10$owEB.ufBsHTR4BYhaB7bKunRwqjFHRtAmyoHag5hMK/LQ6PXhnRza', '8QzRiLugrZFFMAEZMWnkvwzFlh1e6PE9B4H8NfHiY1CT2DMCbnQeBm1wKuZb', 0, 15, '04:00', '21:00', 4, '2021-12-28 18:47:18', '2023-08-08 16:46:24'),
(34, 'Gus Pacheco', 'gus@cruisertravels.com', NULL, '$2y$10$DXH.zXOxEqqjnpOQAg9eWe6jI24jgfiOKbRNT5jQe4AeJCZkMmsZO', 'xglS5kVLG2KPuRraZBrO4EecmLeyI0yjthhcSyjL0BR5nhg4iSbaXEEWCIf4', 1, 500, '09:00', '23:59', 5, '2022-03-10 19:19:59', '2023-01-30 19:18:46'),
(38, 'Felix Saenz', 'felix@cruisertravels.com', NULL, '$2y$10$RN6JAd3MuDP4Ir4lDGUE4eazrc/11w7K/As9E8kw3qns2333h/A4y', 'at4WjpkaVUvAK2G8q9DsCjh6QevaDKuNQhzf0SroSepToHdtNy1DQ1IdIV12', 0, 0, '10:00', '10:01', 1, '2022-07-22 11:22:44', '2024-03-05 13:41:34'),
(39, 'David Cordova', 'david@cruisertravels.com', NULL, '$2y$10$xEgfI9Cn64dirON.axr..uU92olFHBkYFSZ58rpbu3OhFsvtQIQ5C', 'Wv25yMPCLstjXvSDUfoUK3oF6AvxNRcGMrdJ5GeQYrNjL9k71F6aAmxzN5j6', 1, 15, '08:00', '19:00', 5, '2022-08-09 18:01:13', '2022-08-09 18:01:13'),
(42, 'Franco Loli', 'franco@cruisertravels.com', NULL, '$2y$10$UY5D9Af805fpFZUNulLeeOUobNqMZbxVOoOlmrxjXZ4UpkVkL5Y5C', '6IyCAU78Xd1jutBTMZfb2AYMqvap2wOQ6XtaSSsO4mQYAvk7G5QoAKgwFsWK', 0, 15, '07:00', '19:00', 4, '2022-11-15 18:17:10', '2023-07-12 16:26:31'),
(44, 'Choji Itosu', 'choji@cruisertravels.com', NULL, '$2y$10$GmbzD3ky7PzXi62h4.SV2e9o2KXlBYABnhMd.Mz8Paw9SVedTHzKO', 'cDrz3qw4US0h3KECj03AchnTSgkQnyvXWI1hCuSEM0xzX6ZN89p5X7FTd8lc', 0, 15, '05:00', '21:00', 2, '2023-01-30 16:17:39', '2023-07-19 15:00:45'),
(45, 'Jose Vallejos', 'jose@cruisertravels.com', NULL, '$2y$10$5MBog39lbZwcnGdn3ZmLleo1bwYVXOh6KWgGA8Q16iWeXu.adgPe6', '7rG2WZJAwQunO9YVkVu0S4KUo6zZvu0mzBumh4mWPZPS92aAfdmWaoe20KuG', 0, 15, '05:00', '21:00', 2, '2023-01-30 16:18:53', '2023-08-08 16:47:21'),
(50, 'Tamara Claure', 'tamara@cruisertravels.com', NULL, '$2y$10$NY7r8QmPurm5zyyPzWYFHuE/x9iIcnkseI2ZCLHHeAVDNJ5Cv0BZy', '7AfifofPPwi22vxz2LcPscoUEPvthoN9omDdDLofVny6mF9EJRnJWTk3EIDX', 0, 5, '07:00', '20:00', 2, '2023-02-06 19:00:42', '2023-07-17 13:21:12'),
(51, 'Juan Carlos Lizarraga', 'juancarlos@cruisertravels.com', NULL, '$2y$10$U2F/x.UIeHGGQapoNHY2x.g5WGYkbvM/ukKeE6ewwE4kL02cjjJS.', 'YaARNRhdyV9FJHK92z8K3G1ibW0QlwYN3IVEcExzuj33tYXiwCgcssZEKfPP', 1, 15, '09:00', '23:59', 5, '2023-02-06 19:04:31', '2024-01-17 14:36:00'),
(52, 'joe', 'joesdigitalservices@gmail.com', NULL, '$2y$10$ictl6j.0ee.StFttqPJ29ufHXzp5mB/7Ddtk8vVvm8Kuxh939jTHm', NULL, 0, 15, '09:00', '22:00', 2, '2023-03-20 19:48:20', '2024-03-04 14:05:55'),
(54, 'Daniela Paredes', 'daniela@cruisertravels.com', NULL, '$2y$10$qNGpA/.NChUFUDThkCD/0uzQDqacvpalv2Zre9f3x8yW3jcqpcnSO', NULL, 1, 15, '09:00', '23:59', 5, '2023-06-23 18:02:34', '2023-07-12 16:42:32'),
(55, 'Cesar Rodriquez', 'cesar@cruisertravels.com', NULL, '$2y$10$U6GZfGAELSIGQ3IeDXsmreLCiAwokOP39kNbpfFDoJjhQgbQhw.0u', 'a9cn2hetJciRYJOdIn0QWVtn5524uP4TykxbWozufP8bafRQd5JIxcmaRpkh', 0, 18, '08:00', '19:00', 2, '2023-07-12 16:28:28', '2024-04-03 15:27:38'),
(56, 'Nico Kense', 'nico@cruisertravels.com', NULL, '$2y$10$9smdjAu31DDBCVjP8ydrxeVBbFf7ZlTOji/.cL0XJhbSCb4yZfuHO', 'kUaGPUcV6Ki3XARZLwz9VfMOlUgvRaeS4GkIphBe10QnRwptxx6KnM1IszNv', 0, 15, '08:00', '19:00', 2, '2023-07-12 16:31:23', '2023-09-06 16:54:04'),
(57, 'Mauricio Alonso', 'mauricio@cruisertravels.com', NULL, '$2y$10$aLW4KJYLyvPsORJjElw08e2rVUYFQhXEU4pk7x2ngTltYhU69k0hO', NULL, 0, 15, '08:00', '19:00', 1, '2023-07-12 16:38:15', '2023-07-12 16:38:15'),
(58, 'Fabrizio Solari', 'Fabrizio@cruisertravels.com', NULL, '$2y$10$Llf41HcIcBlwebVMQS4iLObuBBr.lJRglKHFGdOmE9uhAlgf/exge', NULL, 0, 15, '08:00', '19:00', 1, '2023-07-12 16:41:20', '2023-07-12 16:41:20'),
(59, 'Dario', 'dario@cruisertravels.com', NULL, '$2y$10$y6q57xKju6FxkLsDC0yeROIGThufK1VzErmW5uOelFzRvp4r6kqKW', '7neipGV6n6jfCh56bBW3lQgxerpl3XWdK8xRtaVxrzIRSk175wcLf0mFd6Mi', 0, 10, '00:01', '23:59', 2, '2023-08-14 13:05:51', '2024-03-08 16:14:26'),
(60, 'Jeremy Garma', 'jeremy@cruisertravels.com', NULL, '$2y$10$FYcDRxZoEidRbQu9NYQg/.OQ5rwzeNecp9Yn4qKwGVWaH3IvxUoPe', NULL, 1, 15, '09:00', '23:59', 5, '2023-09-18 13:29:28', '2023-09-18 13:29:28'),
(61, 'Marcelo Martinez', 'marcelo@cruisertravels.com', NULL, '$2y$10$B4rWzT/WDmFiVrd.QluCAu2/hjX2Q11Yd20MYSY/TRf/4Zc1Ho7IS', NULL, 0, 10, '08:00', '23:59', 4, '2023-12-07 14:10:43', '2023-12-07 14:10:43'),
(62, 'Diego Hinostroza', 'diego@cruisertravels.com', NULL, '$2y$10$NXmGfIEBq/SNesQV.k78turVIiFrKHxzH6atjx1hlcs5AWTuJxIEO', 'xjT0ULaXpO2fAegFMUASXlWX1tEZf7Va3LpMD1GWyHIBABUzVoemIi081zRT', 0, 15, '09:00', '23:59', 1, '2023-12-19 12:13:02', '2023-12-19 12:13:02'),
(63, 'Eduardo Proaño', 'eduardo@cruisertravels.com', NULL, '$2y$10$zo7nSyW49/MOPgMShUFzJ.U8pHLd.YGL.Go9OcNzdhbW5M065EMCG', 'a7oFu96oNHDA87mi2anG3Ta6RQKZa2CcDjq16ePYJE6ePfiqOL7rKYZeHnM6', 0, 20, '09:00', '23:59', 2, '2023-12-19 12:13:58', '2024-04-05 19:58:16'),
(64, 'Mark Barreto', 'mark@cruisertravels.com', NULL, '$2y$10$IfxoA00OZD2vZ1tYGMFjluA6co.jGP35GEzwnbnoAooShigh6we/S', NULL, 0, 5, '00:01', '23:59', 1, '2023-12-21 11:03:52', '2024-01-18 15:44:07'),
(65, 'Deacon Cook', 'jyro@mailinator.com', NULL, '$2y$10$zZPYCTZD0p5XRaTqDCMQJuiqsbwHEFNnOVVVi1oxqfsbyK1YWqzrq', NULL, 0, NULL, NULL, NULL, NULL, '2024-01-07 06:26:17', '2024-01-07 06:26:17'),
(66, 'xpmxvMAf', 'testing@example.com', NULL, '$2y$10$V05RZTBwPwV0aiNqP6Vpku6IAFtzj30WF.LFZE/mML9lJE0YZ/Cg.', 'UKF84HkB56Acb7dENGdufkAbFhyX0t9pIW5h3EOtWzD45FyzYBVmRyF8zC2j', 0, NULL, NULL, NULL, NULL, '2024-02-10 23:08:01', '2024-02-10 23:08:01'),
(67, 'Carlos Cruz', 'carlos@cruisertravels.com', NULL, '$2y$10$nWgJxHXtwSZK21NmmKpS4.9I6baXS4I1c4W7fzrDq9HX.QCjOSw46', NULL, 0, 10, '00:01', '23:59', 1, '2024-04-02 16:15:45', '2024-04-02 16:15:45'),
(68, 'Francisco Condori', 'francisco@cruisertravels.com', NULL, '$2y$10$5e/0HMvl3IRAg0GXZ.xqyuWpgB/Vix7dgCwIzAWPt.Q/5DRW23DBW', NULL, 0, 10, '00:01', '23:59', 1, '2024-04-02 16:56:06', '2024-04-02 16:56:06'),
(69, 'Celeste Villar', 'celeste@cruisertravels.com', NULL, '$2y$10$..2kZbxg45Bw39SNmQ2gCONOt53URWLW5guVe6g0U.SWZq6eYITUK', 'Xewd7Hf5DxV5vTeFOYqmokbSkhNd8PNqyL6jvH5xRVIzW8Mdd5OrLQIR43Op', 0, 10, '00:01', '23:59', 1, '2024-04-02 17:01:44', '2024-04-02 17:01:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `priorities`
--
ALTER TABLE `priorities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `priorities`
--
ALTER TABLE `priorities`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
